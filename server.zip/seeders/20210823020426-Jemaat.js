'use strict';
module.exports = {
  up: async (queryInterface, Sequelize) => {

    await queryInterface.bulkInsert('Jemaats', [
      {

        namaJemaat: "Klasis Makassar",
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {

        namaJemaat: "Tamalate",
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {

        namaJemaat: "Bawakaraeng",
        createdAt: new Date(),
        updatedAt: new Date()
      }
    ]);

  },

  down: async (queryInterface, Sequelize) => {


    await queryInterface.bulkDelete('Jemaats', null, {});

  }
};
